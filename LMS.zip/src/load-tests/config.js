export const BASE_URL = 'http://localhost:4000';

export const TEST_PASSWORD = '123456';

// These MUST exist in DB
export const QUIZ_ID = 'PUT_PUBLISHED_QUIZ_GROUP_ID_HERE';
