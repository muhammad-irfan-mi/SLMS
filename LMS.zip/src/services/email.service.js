const nodemailer = require('nodemailer');

class EmailService {
    constructor() {
        this.transporter = nodemailer.createTransport({
            host: process.env.SMTP_HOST || 'smtp.gmail.com',
            port: process.env.SMTP_PORT || 587,
            secure: process.env.SMTP_SECURE === 'true',
            auth: {
                user: process.env.SMTP_USER,
                pass: process.env.SMTP_PASS,
            },
        });
    }

    async sendOTPEmail(email, otpCode, schoolName) {
        const mailOptions = {
            from: `"School Management System" <${process.env.SMTP_USER}>`,
            to: email,
            subject: 'Verify Your School Registration',
            html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">School Registration Verification</h2>
          <p>Dear ${schoolName},</p>
          <p>Thank you for registering your school. Please use the following OTP to verify your email address:</p>
          <div style="background-color: #f4f4f4; padding: 15px; border-radius: 5px; text-align: center; margin: 20px 0;">
            <h1 style="color: #0066cc; letter-spacing: 5px; margin: 0;">${otpCode}</h1>
          </div>
          <p>This OTP is valid for <strong>10 minutes</strong>.</p>
          <p>If you didn't request this registration, please ignore this email.</p>
          <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
          <p style="color: #666; font-size: 12px;">This is an automated message, please do not reply.</p>
        </div>
      `,
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return true;
        } catch (error) {
            console.error('Error sending email:', error);
            throw new Error('Failed to send OTP email');
        }
    }

    async sendPasswordSetupEmail(email, schoolName, schoolId) {
        const mailOptions = {
            from: `"School Management System" <${process.env.SMTP_USER}>`,
            to: email,
            subject: 'Set Your School Account Password',
            html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Welcome to School Management System</h2>
          <p>Dear ${schoolName},</p>
          <p>Your school registration has been verified successfully!</p>
          <p>Your School ID: <strong>${schoolId}</strong></p>
          <p>Please click the link below to set your password and complete your account setup:</p>
          <div style="text-align: center; margin: 25px 0;">
            <a href="${process.env.FRONTEND_URL}/set-password?email=${encodeURIComponent(email)}&schoolId=${schoolId}" 
               style="background-color: #0066cc; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;">
              Set Your Password
            </a>
          </div>
          <p>This link will expire in 24 hours.</p>
          <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
          <p style="color: #666; font-size: 12px;">If you didn't request this registration, please contact support.</p>
        </div>
      `,
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return true;
        } catch (error) {
            console.error('Error sending email:', error);
            throw new Error('Failed to send password setup email');
        }
    }

    async sendUserOTPEmail(email, otpCode, userName) {
        const mailOptions = {
            from: `"School Management System" <${process.env.EMAIL_SENDER}>`,
            to: email,
            subject: 'Verify Your Account',
            html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #333;">Account Verification</h2>
        <p>Dear ${userName},</p>
        <p>Please use the following OTP to verify your account:</p>
        <div style="background-color: #f4f4f4; padding: 15px; border-radius: 5px; text-align: center; margin: 20px 0;">
          <h1 style="color: #0066cc; letter-spacing: 5px; margin: 0;">${otpCode}</h1>
        </div>
        <p>This OTP is valid for <strong>10 minutes</strong>.</p>
        <p>After verification, you can set your password in the mobile app.</p>
        <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
        <p style="color: #666; font-size: 12px;">This is an automated message, please do not reply.</p>
      </div>
    `,
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return true;
        } catch (error) {
            console.error('Error sending user OTP email:', error);
            throw new Error('Failed to send OTP email');
        }
    }
}
module.exports = new EmailService();