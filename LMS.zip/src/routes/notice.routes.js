// const express = require("express");
// const router = express.Router();
// const { createNotice, getNoticesForStudent, updateNotice, deleteNotice, getNotices } = require("../controllers/noticeController");
// const { isTeacherOrAdminOfficeOrSchool, protect, isStudent } = require("../middlewares/auth");

// router.post("/", protect, isTeacherOrAdminOfficeOrSchool, createNotice);
// router.get("/", protect, isTeacherOrAdminOfficeOrSchool, getNotices);
// router.get("/student", protect, isStudent, getNoticesForStudent);
// router.put("/:id", protect, isTeacherOrAdminOfficeOrSchool, updateNotice);
// router.delete("/:id", protect, isTeacherOrAdminOfficeOrSchool, deleteNotice);

// module.exports = router;








const express = require("express");
const router = express.Router();
const {
    createNotice,
    getNoticesForStudent,
    updateNotice,
    deleteNotice,
    getNotices
} = require("../controllers/noticeController");

const {
    validate,
    validateQuery,
    createNoticeSchema,
    updateNoticeSchema,
    getNoticesQuerySchema,
    getNoticesForStudentQuerySchema
} = require("../validators/notice.validator");

const {
    isTeacherOrAdminOfficeOrSchool,
    protect,
    isStudent
} = require("../middlewares/auth");

// Create notice (teachers/admins/school)
router.post(
    "/",
    protect,
    isTeacherOrAdminOfficeOrSchool,
    validate(createNoticeSchema),
    createNotice
);

// Get notices (teachers/admins/school)
router.get(
    "/",
    protect,
    isTeacherOrAdminOfficeOrSchool,
    validateQuery(getNoticesQuerySchema),
    getNotices
);

// Get notices for student
router.get(
    "/student",
    protect,
    isStudent,
    validateQuery(getNoticesForStudentQuerySchema),
    getNoticesForStudent
);

// Update notice (teachers/admins/school)
router.put(
    "/:id",
    protect,
    isTeacherOrAdminOfficeOrSchool,
    validate(updateNoticeSchema),
    updateNotice
);

// Delete notice (teachers/admins/school)
router.delete(
    "/:id",
    protect,
    isTeacherOrAdminOfficeOrSchool,
    deleteNotice
);

module.exports = router;