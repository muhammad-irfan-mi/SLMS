// const express = require("express");
// const router = express.Router();

// const {
//     markAttendance,
//     updateAttendance,
//     getAttendanceBySection,
//     getAttendanceByStudent,
//     // getAttendanceByDateOrRange,
//     // getStudentAttendanceByDateOrRange
// } = require("../controllers/attendance.controller");
// const { markAttendanceSchema, updateAttendanceSchema, studentAttendanceQuerySchema } = require("../validators/attendance.validation");
// const { isTeacher, protect, isTeacherOrAdminOfficeOrSchool, allowedRoles, isTeacherOrStudent } = require("../middlewares/auth");
// const validate = require("../middlewares/validate");



// router.post("/", protect, isTeacher, validate(markAttendanceSchema), markAttendance);
// router.patch("/:attendanceId", protect, isTeacherOrAdminOfficeOrSchool, validate(updateAttendanceSchema), updateAttendance);

// router.get("/section/:sectionId",
//     protect,
//     isTeacherOrAdminOfficeOrSchool,
//     validate(studentAttendanceQuerySchema, "query"),
//     getAttendanceBySection
// );

// router.get(
//     "/student/:studentId",
//     protect,
//     allowedRoles,
//     validate(studentAttendanceQuerySchema, "query"),
//     getAttendanceByStudent
// );


// // router.get("/section/:sectionId/date",
// //     protect,
// //     isTeacherOrAdminOfficeOrSchool,
// //     validate(dateFilterSchema, "query"),
// //     getAttendanceByDateOrRange
// // );

// // router.get("/student/:studentId/date",
// //     protect,
// //     isTeacherOrStudent,
// //     validate(dateFilterSchema, "query"),
// //     getStudentAttendanceByDateOrRange
// // );

// module.exports = router;



















// attendance.routes.js
const express = require("express");
const router = express.Router();

const {
    markAttendance,
    updateAttendance,
    getAttendanceBySection,
    getAttendanceByStudent,
} = require("../controllers/attendance.controller");

const { 
    markAttendanceSchema, 
    updateAttendanceSchema, 
    studentAttendanceQuerySchema,
    sectionIdParamSchema,
    studentIdParamSchema,
    attendanceIdParamSchema
} = require("../validators/attendance.validation");

const { 
    isTeacher, 
    protect, 
    isTeacherOrAdminOfficeOrSchool, 
    allowedRoles, 
    isTeacherOrStudent 
} = require("../middlewares/auth");

const validate = require("../middlewares/validate");

// Mark attendance
router.post("/", 
    protect, 
    isTeacher, 
    validate(markAttendanceSchema), 
    markAttendance
);

// Update attendance
router.patch("/:attendanceId", 
    protect, 
    isTeacherOrAdminOfficeOrSchool, 
    validate(attendanceIdParamSchema, "params"), 
    validate(updateAttendanceSchema), 
    updateAttendance
);

// Get attendance by section
router.get("/section/:sectionId",
    protect,
    isTeacherOrAdminOfficeOrSchool,
    validate(sectionIdParamSchema, "params"),
    validate(studentAttendanceQuerySchema, "query"),
    getAttendanceBySection
);

// Get attendance by student
router.get(
    "/student/:studentId",
    protect,
    allowedRoles,
    validate(studentIdParamSchema, "params"),
    validate(studentAttendanceQuerySchema, "query"),
    getAttendanceByStudent
);

module.exports = router;