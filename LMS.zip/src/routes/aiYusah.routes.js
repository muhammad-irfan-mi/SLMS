// const router = require("express").Router();
// const { createAiVideo, updateAiVideo, deleteAiVideo, getVideosForSuperadmin, getVideosBySchool, getVideoById } = require("../controllers/aiYusahVideo.controller");
// const { protect, isSuperAdmin, allowedRoles } = require("../middlewares/auth");


// router.post("/", protect, isSuperAdmin, createAiVideo);
// router.put("/:id", protect, isSuperAdmin, updateAiVideo);
// router.delete("/:id", protect, isSuperAdmin, deleteAiVideo);
// router.get("/", protect, isSuperAdmin, getVideosForSuperadmin);

// router.get("/school/:id", protect, allowedRoles, getVideoById);
// router.get("/school", protect, allowedRoles, getVideosBySchool);

// router.get("/:id", protect, allowedRoles, getVideoById);

// module.exports = router;














const router = require("express").Router();
const { 
  createAiVideo, 
  updateAiVideo, 
  deleteAiVideo, 
  getVideosForSuperadmin, 
  getVideosForAll, 
  getVideoById,
  toggleVideoStatus
} = require("../controllers/aiYusahVideo.controller");
const { validateVideo, validateFilter } = require("../validators/aiYusahVideo.validation");
const { protect, isSuperAdmin } = require("../middlewares/auth");

// Middleware to detect and attach role for non-superadmin users
const attachUserRole = (req, res, next) => {
  // If user doesn't have role field but has schoolId, it's a school
  if (!req.user.role && req.user.schoolId) {
    req.user.role = 'school';
  }
  // If user doesn't have role but has verified field, it's a school
  else if (!req.user.role && req.user.verified !== undefined && req.user.email) {
    req.user.role = 'school';
  }
  next();
};

// Superadmin routes (CRUD operations)
router.post("/",
  protect,
  isSuperAdmin,
  validateVideo,
  createAiVideo
);

router.put("/:id",
  protect,
  isSuperAdmin,
  validateVideo,
  updateAiVideo
);

router.delete("/:id",
  protect,
  isSuperAdmin,
  deleteAiVideo
);

router.patch("/:id/status",
  protect,
  isSuperAdmin,
  toggleVideoStatus
);

// Superadmin view all videos
router.get("/admin",
  protect,
  isSuperAdmin,
  validateFilter,
  getVideosForSuperadmin
);

// All other users view videos (school, teacher, admin_office, student)
router.get("/",
  protect,
  attachUserRole,
  validateFilter,
  getVideosForAll
);

// Get single video by ID (for all authenticated users)
router.get("/:id",
  protect,
  attachUserRole,
  getVideoById
);

module.exports = router;