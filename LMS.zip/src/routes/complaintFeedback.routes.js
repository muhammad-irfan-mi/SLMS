// const express = require("express");
// const router = express.Router();

// const { createEntry, updateEntry, deleteEntry, reviewComplaint, getComplain, getComplainByStudent } = require("../controllers/complaintFeedback.controller");
// const { protect, isStudent, isAdminOffice } = require("../middlewares/auth");


// router.post("/", protect, isStudent, createEntry);
// router.put("/:id", protect, updateEntry);
// router.delete("/:id", protect, isStudent, deleteEntry);
// router.post("/:id/review", protect, isAdminOffice, reviewComplaint);
// router.get("/", protect, isAdminOffice, getComplain);
// router.get("/student", protect, isStudent, getComplainByStudent);

// module.exports = router;















const express = require("express");
const router = express.Router();

const {
    createEntry,
    updateEntry,
    deleteEntry,
    reviewComplaint,
    getComplain,
    getComplainByStudent,
    updateStatus,
    markAsResolvedByStudent
} = require("../controllers/complaintFeedback.controller");

const {
    validate,
    validateQuery,
    createEntrySchema,
    updateEntrySchema,
    reviewComplaintSchema,
    getEntriesSchema
} = require("../validators/complaintFeedback.validation");

const { 
    protect, 
    isStudent, 
    isAdminOffice,
    isTeacherOrAdminOfficeOrSchool, 
    allowedRoles
} = require("../middlewares/auth");

// Student routes
router.post(
    "/",
    protect,
    isStudent,
    validate(createEntrySchema),
    createEntry
);

router.get(
    "/student",
    protect,
    isStudent,
    validateQuery(getEntriesSchema),
    getComplainByStudent
);

// Admin/Teacher routes
router.get(
    "/",
    protect,
    isTeacherOrAdminOfficeOrSchool,
    validateQuery(getEntriesSchema),
    getComplain
);

router.post(
    "/:id/review",
    protect,
    allowedRoles,
    validate(reviewComplaintSchema),
    reviewComplaint
);

router.patch(
    "/:id/status",
    protect,
    isAdminOffice,
    updateStatus
);

// Common routes
router.put(
    "/:id",
    protect,
    validate(updateEntrySchema),
    updateEntry
);

router.put(
    "/:id/resolve",
    protect,
    isStudent,
    markAsResolvedByStudent
);

router.delete(
    "/:id",
    deleteEntry
);

module.exports = router;