// const express = require("express");
// const {
//     createDiary,
//     getDiaryBySection,
//     getStudentDiary,
//     updateDiary,
//     deleteDiary,
// } = require("../controllers/diary.controller");
// const { protect, isTeacher, isTeacherOrStudent } = require("../middlewares/auth");

// const router = express.Router();

// router.post("/", protect, isTeacher, createDiary);
// router.patch("/:diaryId", protect, isTeacher, updateDiary);
// router.delete("/:diaryId", protect, isTeacher, deleteDiary);
// router.get("/section/:sectionId", protect, isTeacherOrStudent, getDiaryBySection);
// router.get("/student", protect, isTeacherOrStudent, getStudentDiary);

// module.exports = router;











// routes/diary.routes.js
const express = require("express");
const {
    createDiary,
    getDiaryBySection,
    getStudentDiary,
    updateDiary,
    deleteDiary,
} = require("../controllers/diary.controller");
const { protect, isTeacherOrAdminOfficeOrSchool, isTeacherOrStudent } = require("../middlewares/auth");
const { upload } = require("../utils/multer");

const router = express.Router();

// Create diary with image upload (only class incharge/admin)
router.post(
    "/",
    protect,
    isTeacherOrAdminOfficeOrSchool,
    upload.fields([
        { name: "images", maxCount: 2 },
        { name: "pdf", maxCount: 1 }
    ]),
    createDiary
);

// Update diary with image upload
router.patch(
    "/:diaryId",
    protect,
    isTeacherOrAdminOfficeOrSchool,
    upload.fields([
        { name: "images", maxCount: 2 },
        { name: "pdf", maxCount: 1 }
    ]),
    updateDiary
);

// Delete diary
router.delete(
    "/:diaryId",
    protect,
    isTeacherOrAdminOfficeOrSchool,
    deleteDiary
);

// Get diary by section (accessible to class incharge, teachers with access, and students)
router.get(
    "/section/:sectionId",
    protect,
    isTeacherOrStudent,
    getDiaryBySection
);

// Get student's own diary
router.get(
    "/student",
    protect,
    isTeacherOrStudent,
    getStudentDiary
);

module.exports = router;