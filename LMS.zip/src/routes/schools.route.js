// const express = require("express");
// const router = express.Router();
// const { upload } = require("../utils/multer");
// const {
//     addSchoolBySuperAdmin,
//     deleteSchoolBySuperAdmin,
//     editSchoolBySuperAdmin,
//     getAllSchools,
//     getSchoolById
// } = require('../controllers/schoolController');
// const { setPassword, schoolLogin } = require("../controllers/authController");
// const { protect, isSuperAdmin, isAdminOffice } = require("../middlewares/auth");
// const { validationSchemas } = require("../validators/school.validator");
// const validate = require("../middlewares/validate");

// router.post(
//     "/add-school",
//     protect,
//     isSuperAdmin,
//     upload.fields([  
//         { name: "cnicFront", maxCount: 1 },
//         { name: "cnicBack", maxCount: 1 },
//         { name: "nocDoc", maxCount: 1 },
//     ]),
//     validate(validationSchemas.addSchool),  
//     addSchoolBySuperAdmin
// );

// router.put(
//     "/edit-school/:id",
//     protect,
//     isSuperAdmin,
//     upload.fields([
//         { name: "cnicFront", maxCount: 1 },
//         { name: "cnicBack", maxCount: 1 },
//         { name: "nocDoc", maxCount: 1 },
//     ]),
//     validate(validationSchemas.idParam, 'params'),
//     validate(validationSchemas.updateSchool),
//     editSchoolBySuperAdmin
// );

// router.delete(
//     "/delete-school/:id",
//     protect,
//     isSuperAdmin,
//     validate(validationSchemas.idParam, 'params'),
//     deleteSchoolBySuperAdmin
// );

// router.get(
//     "/all",
//     protect,
//     isSuperAdmin,
//     validate(validationSchemas.paginationQuery, 'query'),
//     getAllSchools
// );

// router.get(
//     "/:id",
//     protect,
//     isAdminOffice,
//     validate(validationSchemas.idParam, 'params'),
//     getSchoolById
// );

// router.post(
//     "/set-school-password",
//     validate(validationSchemas.setPassword),
//     setPassword
// );

// router.post(
//     "/school-login",
//     validate(validationSchemas.login),
//     schoolLogin
// );

// module.exports = router;











const express = require('express');
const router = express.Router();
const { validationSchemas } = require('../validators/school.validator');
const validate = require('../middlewares/validate');
const multer = require('multer');
const { verifySchoolOTP, resendSchoolOTP, setSchoolPassword, addSchoolBySuperAdmin, editSchoolBySuperAdmin, deleteSchoolBySuperAdmin, getAllSchools, getPendingRegistrations, getSchoolById } = require('../controllers/schoolController');
const { upload } = require("../utils/multer");

// OTP Verification Routes
router.post(
    '/verify-otp',
    validate(validationSchemas.verifyOTP),
    verifySchoolOTP
);

router.post(
    '/resend-otp',
    validate(validationSchemas.resendOTP),
    resendSchoolOTP
);

router.post(
    '/set-password',
    validate(validationSchemas.setPassword),
    setSchoolPassword
);

// Existing routes with validation
router.post(
    '/add-school',
    upload.fields([
        { name: 'cnicFront', maxCount: 1 },
        { name: 'cnicBack', maxCount: 1 },
        { name: 'nocDoc', maxCount: 1 }
    ]),
    validate(validationSchemas.addSchool),
    addSchoolBySuperAdmin
);

router.put(
    '/edit/:id',
    upload.fields([
        { name: 'cnicFront', maxCount: 1 },
        { name: 'cnicBack', maxCount: 1 },
        { name: 'nocDoc', maxCount: 1 }
    ]),
    validate(validationSchemas.idParam, 'params'),
    validate(validationSchemas.updateSchool),
    editSchoolBySuperAdmin
);

router.delete(
    '/delete/:id',
    validate(validationSchemas.idParam, 'params'),
    deleteSchoolBySuperAdmin
);

router.get(
    '/',
    validate(validationSchemas.paginationQuery, 'query'),
    getAllSchools
);

router.get(
    '/pending',
    getPendingRegistrations
);

router.get(
    '/:id',
    validate(validationSchemas.idParam, 'params'),
    getSchoolById
);

module.exports = router;