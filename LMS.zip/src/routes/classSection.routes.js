// const express = require("express");
// const router = express.Router();
// const {
//     deleteSectionFromClass,
//     deleteClass,
//     getClassesBySchool,
//     addMultipleClassesWithSections,
//     updateAllClassesAndSections,
//     assignSectionIncharge,
// } = require("../controllers/classSection.controller");
// const { protect, isAdminOffice } = require("../middlewares/auth");

// router.post("/add",
//     protect,
//     isAdminOffice,
//     addMultipleClassesWithSections
// );
// router.put("/update-all",
//     protect,
//     isAdminOffice,
//     updateAllClassesAndSections
// );
// router.delete("/delete-section",
//     protect,
//     isAdminOffice,
//     deleteSectionFromClass
// );
// router.delete("/:id",
//     protect,
//     isAdminOffice,
//     deleteClass
// );
// router.get("/:schoolId",
//     protect,
//     isAdminOffice,
//     getClassesBySchool
// );

// router.post('/assing-incharge', protect, isAdminOffice, assignSectionIncharge)

// module.exports = router;









const express = require("express");
const router = express.Router();
const {
    deleteSectionFromClass,
    deleteClass,
    getClassesBySchool,
    addMultipleClassesWithSections,
    updateAllClassesAndSections,
    assignSectionIncharge,
} = require("../controllers/classSection.controller");
const { protect, isAdminOffice } = require("../middlewares/auth");
const validate = require("../middlewares/validate");
const {
    addMultipleClassesValidation,
    updateAllClassesValidation,
    deleteSectionValidation,
    assignInchargeValidation,
    paginationQueryValidation,
    idParamValidation,
    schoolIdParamValidation,
} = require("../validators/classSection.validation");

// Apply protection and admin/office middleware to all routes
router.use(protect, isAdminOffice);

// Add multiple classes with sections
router.post(
    "/add",
    validate(addMultipleClassesValidation),
    addMultipleClassesWithSections
);

// Update all classes and sections
router.put(
    "/update-all",
    validate(updateAllClassesValidation),
    updateAllClassesAndSections
);

// Delete section from a class
router.delete(
    "/delete-section",
    validate(deleteSectionValidation),
    deleteSectionFromClass
);

// Delete an entire class
router.delete(
    "/:id",
    validate(idParamValidation, 'params'),
    deleteClass
);

// Get classes by school with pagination
router.get(
    "/:schoolId",
    validate(schoolIdParamValidation, 'params'),
    validate(paginationQueryValidation, 'query'),
    getClassesBySchool
);

// Assign section incharge
router.post(
    '/assign-incharge',
    validate(assignInchargeValidation),
    assignSectionIncharge
);

module.exports = router;